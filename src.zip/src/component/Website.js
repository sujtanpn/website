import React from 'react';
import { FaFacebookSquare , FaInstagramSquare , FaBars} from 'react-icons/fa';
import styles from "../website/Website.module.css";

const Website = () => {
  return (
   <header>
    <h3> Logo</h3>
    <nav>
        <ul>
        <a href=''>Home</a>
        <a href=''>About</a>
        <a href=''>Contact</a>
        </ul>

    </nav>
    <button className='btn'>
            <FaFacebookSquare />
        </button>
    <button>
        <FaBars />
    </button>
   </header>
  )
}

export default Website
