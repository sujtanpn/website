import React from 'react'
import Website from './component/Website'

const App = () => {
  return (
   <Website />
  )
}

export default App
